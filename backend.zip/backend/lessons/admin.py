from django.contrib import admin
from .models import Subject, LessonText

admin.site.register(Subject)
admin.site.register(LessonText)
